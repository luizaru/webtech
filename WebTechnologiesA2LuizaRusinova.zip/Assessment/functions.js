$(window).scroll(function() {
    var scrollTop = $(this).scrollTop();
    console.log(scrollTop);
    $(".banner-1").css("top", -(scrollTop *0.4)+"px");
    if(scrollTop>1200){
      $(".banner-2").css("top",+450 -(scrollTop *0.4)+"px");
    } if (scrollTop>2252) {
        $(".banner-3").css("top",+500 -(scrollTop *0.2)+"px");
    }  if (scrollTop>3250) {
        $(".banner-4").css("top",+500 -(scrollTop *0.2)+"px");
    }if($(window).width()<500) {
        $(".banner-2").css("top",+150 -(scrollTop *0.2)+"px");
        $(".banner-3").css("top",+1200 -(scrollTop *0.2)+"px");
        $(".banner-2").css("top",+150 -(scrollTop *0.2)+"px");
    }
  });

var scrollLink = $(".scroll");

  scrollLink.click(function(e){
    e.preventDefault();
    $("body,html").animate({
      scrollTop: $(this.hash).offset().top
    },1000)
});

var form = $('#contact'),
    submit = form.find('[name="submit"]');

form.on('submit', function(e) {
  e.preventDefault();
  
  
  if (submit.attr('value') !== 'Send')
    return;
  
  var valid = true;
  form.find('input, textarea').removeClass('invalid').each(function() {
    if (!this.value) {
      $(this).addClass('invalid');
      valid = false;
    }
  });
  
  if (!valid) {
    form.animate({left: '-3em'},  50)
        .animate({left:  '3em'}, 100)
        .animate({left:    '0'},  50);
  } else {
    submit.attr('value', 'Sending...')
          .css({boxShadow: '0 0 200em 200em rgba(225, 225, 225, 0.6)',
                backgroundColor: '#ccc'});
    // simulate AJAX response
    setTimeout(function() {
      // step 1: slide labels and inputs
      // when AJAX responds with success
      // no animation for AJAX failure yet
      form.find('label')
          .animate({left: '100%'}, 500)
          .animate({opacity: '0'}, 500);
    }, 1000);
    setTimeout(function() {
      // step 2: show thank you message after step 1
      submit.attr('value', 'Thank you :)')
            .css({boxShadow: 'none'});
    }, 2000);
    setTimeout(function() {
      // step 3: reset
      form.find('input, textarea').val('');
      form.find('label')
          .css({left: '0'})
          .animate({opacity: '1'}, 500);
      submit.attr('value', 'Send')
            .css({backgroundColor: ''});
    }, 4000);
  }
});